import { Component } from '@angular/core';

@Component({
  selector: 'app-pages-1DOY',
  templateUrl: './pages-1DOY.component.html',
  styleUrls: []
})
export class Pages1DOYComponent {}
