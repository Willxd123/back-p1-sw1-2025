import { Pages1DOYComponent } from './pages/pages-1DOY/pages-1DOY.component';
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', component: Pages1DOYComponent },

];
