import { Pages480GComponent } from './pages/pages-480G/pages-480G.component';
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', component: Pages480GComponent },

];
