import { Component } from '@angular/core';

@Component({
  selector: 'app-pages-480G',
  templateUrl: './pages-480G.component.html',
  styleUrls: []
})
export class Pages480GComponent {}
