import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms'; // Importa FormsModule para habilitar ngModel
import { ApiService } from '../../services/api.service';



@Component({
  selector: 'app-welcome',
  standalone: true,
  imports: [ FormsModule],
  providers: [ApiService], // Añadir FormsModule aquí
  templateUrl: './welcome.component.html',
})
export class WelcomeComponent {

  constructor(
    private router: Router,

  ) {}




}
